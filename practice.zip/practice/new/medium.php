<!DOCTYPE html>
<html lang="en">
<head>
    <title>Account Created</title>
</head>
<body bgcolor='lightgrey' align="center">
    
    <h2>Account Created Successfully!</h2>
    <h3>You can now log in to your account.</h3>
    <form method ='POST' action = 'login.php'>
        <br> <br>
        <input type = 'submit' name ='submit' value ='Log In'>  
</form>
</body>
</html>